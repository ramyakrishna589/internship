Advanced Student Management System - Java Assignment

How to Run:
1. Compile all Java files:
   javac Student.java StudentManager.java Main.java

2. Run the program:
   java Main

Features:
- Add, Remove, Update, Search students
- Display all students sorted by ID
- Saves data in students.dat file using serialization